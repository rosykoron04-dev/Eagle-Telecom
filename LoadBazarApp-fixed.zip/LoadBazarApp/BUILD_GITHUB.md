# GitHub APK Build

This project is configured for GitHub Actions. The workflow uses JDK 17 and Gradle 8.10.2, then builds `app-debug.apk` and uploads it as an Actions artifact.

The project does not require a checked-in `gradlew` wrapper for the GitHub workflow because the workflow installs Gradle itself.
