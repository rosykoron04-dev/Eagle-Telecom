# Quick Pay Android APK

এই project-এ Quick Pay-এর Login, Register এবং Home UI Android WebView-এর ভিতরে প্যাক করা আছে।

## GitHub থেকে APK বানানো
1. এই project-এর সব ফাইল GitHub repository-র root-এ upload করুন।
2. **Actions** ট্যাবে যান।
3. **Build Quick Pay APK** workflow খুলে **Run workflow** চাপুন।
4. Build শেষ হলে workflow run-এর **Artifacts** থেকে `Quick-Pay-debug-apk` ZIP download করুন।
5. ZIP খুলে `app-debug.apk` ফোনে install করুন।

এটি UI/demo APK; বাস্তব recharge/payment/backend এখনো সংযুক্ত নয়।

## Backend integration update
- Clean Android source path: app/src/main/java/com/quickpay/app/MainActivity.java
- Firebase Auth + Firestore user profile/balance listener enabled.
- Add Money creates depositRequests as PENDING.
- Mobile Banking, Bank Transfer, Mobile Recharge, Bill Pay and Special Offer create separate Firebase request records.
- Group Chat uses groupChatMessages with PENDING -> admin approval -> APPROVED flow.
- Payment numbers can be read from Firebase paymentNumbers/{bkash,nagad,rocket} or settings/paymentNumbers.
- Live Activity reads liveActivities, maximum 500, and rotates using settings/general.liveRotateSeconds.
- No real money or recharge API is connected.
